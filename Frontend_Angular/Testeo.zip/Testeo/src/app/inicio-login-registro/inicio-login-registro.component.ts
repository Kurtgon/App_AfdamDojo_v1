import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inicio-login-registro',
  templateUrl: './inicio-login-registro.component.html',
  styleUrls: ['./inicio-login-registro.component.scss']
})
export class InicioLoginRegistroComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
