import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-registro',
  templateUrl: './registro.component.html',
  styleUrls: ['./registro.component.scss']
})
export class RegistroComponent implements OnInit {

    // Propiedades de la clase
    loginForm: FormGroup; // Permite tener un objeto linkado a los campos del formulario de autenticación
    ocultarPassword: boolean = true; // Utilizado para conocer si se muestra o se oculta el contenido del campo password

  constructor() { }

  ngOnInit(): void {
  }

}
