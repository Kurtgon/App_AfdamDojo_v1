package com.jacaranda.appDojoAfdam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppDojoAfdamApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppDojoAfdamApplication.class, args);
	}

}
