//Datos del Alumno
export interface Alumno{
    id?:number;
    name: string;
    surnames: string;
    dni: string;
    tfl: string;
    address: string;
    birthdate: string;
    contact: string;
    allergy: string;
    disciplinas: string;
}