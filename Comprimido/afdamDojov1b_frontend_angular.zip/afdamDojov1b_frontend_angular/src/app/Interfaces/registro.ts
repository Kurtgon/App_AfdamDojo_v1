//Datos del usuario registro
export interface Registro{
    id?:number;
    username: string;
    password: string;
    email: string;
    name: string;
    surnames: string;
    dni: string;
    tfl: string;
    address: string;
    birthdate: string;
    contact: string;
    allergy: string;
    disciplinas: string;
}