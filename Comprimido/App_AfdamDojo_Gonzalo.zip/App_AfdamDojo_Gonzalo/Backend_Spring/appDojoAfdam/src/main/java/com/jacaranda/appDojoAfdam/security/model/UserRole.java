package com.jacaranda.appDojoAfdam.security.model;

public enum UserRole {

	ADMIN, SENSEI, STUDENT
	
}
