package com.jacaranda.appDojoAfdam.model.entity.enums;

public enum Disciplinas {

	KICKBOXING(0),
	MMA(1),
	CARDIOFITBAG(2),
	JIUJITSU(3),
	NINJUSTSU(4),
	TAICHI(5);
	
	Disciplinas (int i){}
}
