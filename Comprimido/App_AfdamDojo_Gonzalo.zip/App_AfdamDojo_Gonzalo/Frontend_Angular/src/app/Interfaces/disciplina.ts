//Datos de disciplina
export interface Disciplina {
    id?: number;
    name: string;

}